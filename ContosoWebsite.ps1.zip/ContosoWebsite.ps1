Configuration ContosoWebsite
{
  param ($MachineName)

  Node $MachineName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = �Present�
      Name = �Web-Server�
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = �Present�
      Name = �Web-Asp-Net45�
    }

     WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }
  }
}

$sitename = "Default Web Site" 
xWebsite MainHTTPWebsite  
{  
    Ensure          = "Present"  
    Name            = $sitename
    ApplicationPool = "DefaultAppPool" 
    State           = "Started"  
    PhysicalPath    = "%SystemDrive%\inetpub\wwwroot"  
    BindingInfo     = @(
                        @(MSFT_xWebBindingInformation   
                            {  
                                Protocol              = "HTTP"
                                Port                  =  8080 
                                HostName              = ""
                            }
                        )
                      )
    #DependsOn       = "[File]copyWebFiles"  
} 